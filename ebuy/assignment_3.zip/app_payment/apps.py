from django.apps import AppConfig


class AppPaymentConfig(AppConfig):
    name = 'app_payment'
