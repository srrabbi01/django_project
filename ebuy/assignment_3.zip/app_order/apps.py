from django.apps import AppConfig


class AppOrderConfig(AppConfig):
    name = 'app_order'
