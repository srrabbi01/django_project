from django.contrib import admin

from app_vendor.models import VendorShop

# Register your models here.
admin.site.register(VendorShop)