from django.apps import AppConfig


class AppShopConfig(AppConfig):
    name = 'app_shop'
