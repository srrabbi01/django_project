from django.contrib import admin
from app_payment.models import BillingAddress

# Register your models here.

admin.site.register(BillingAddress)
